// component
import SvgColor from '../../../components/svg-color';

// ----------------------------------------------------------------------

const icon = (name) => <SvgColor src={`/assets/icons/navbar/${name}.svg`} sx={{ width: 1, height: 1 }} />;

const navConfig = (userRole) => {
  const commonNavItems = [
    {
      title: 'login',
      path: '/login',
      icon: icon('ic_lock'),
    },
    {
      title: 'Not found',
      path: '/404',
      icon: icon('ic_disabled'),
    },
  ];

  const studentNavItems = [
    {
      title: 'Home',
      path: '/dashboard/home',
      icon: icon('ic_home'),
    },
    {
      title: 'Students',
      path: '/dashboard/students',
      icon: icon('ic_users'),
    },
    // ...rest of the student items
  ];

  const adminNavItems = [
    {
      title: 'Create User',
      path: '/dashboard/create-user',
      icon: icon('ic_add_user'),
    },
    {
      title: 'Add Data',
      path: '/dashboard/add-data',
      icon: icon('ic_data'),
    },
    // ...rest of the admin items
  ];

  const teacherNavItems = [
    {
      title: 'Home',
      path: '/dashboard/home',
      icon: icon('ic_home'),
    },
    {
      title: 'Students',
      path: '/dashboard/students',
      icon: icon('ic_users'),
    },
    // ...rest of the teacher items
  ];

  switch (userRole) {
    case 'student':
      return [...studentNavItems, ...commonNavItems];
    case 'admin':
      return [...adminNavItems, ...commonNavItems];
    case 'teacher':
      return [...teacherNavItems, ...commonNavItems];
    default:
      return [...commonNavItems];
  }
};


export default navConfig;
